void main(){
__asm__("movl $0, %eax;"
	"movl $1, %ebx;"
);
}
